
#feature-id    RGB2SyntheticL : Batch Processing > RGB2SyntheticL

#feature-info  RGB to Synthetic Luminance Generator.<br/>\
   <br/>\
   A script that combines RGB images to create a synthetic luminance image.<br/>\
   <br/>\
   Copyright &copy; 2024 Conci Andrea - Cionki<br/>

#feature-icon  @script_icons_dir/RGB2SyntheticL.svg

#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/SectionBar.jsh>
//#include <pjsr/PushButton.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FontFamily.jsh>
//#include <pjsr/Bitmap.jsh>

function createColorSquare(color) {
    let bmp = new Bitmap(16, 16);
    bmp.fill(color);
    return bmp;
}

function createMixedColorSquare() {
    let bmp = new Bitmap(16, 16);
    bmp.fill(0xFF00FF00); //Green
    let g = new Graphics(bmp);
    g.fillRect(0, 0, 8, 8, new Brush(0xFFFF0000)); // Red
    g.fillRect(8, 8, 16, 16, new Brush(0xFF0000FF)); // Blue
    g.end();
    return bmp;
}



function RGBCombinerDialog() {
    this.__base__ = Dialog;
    this.__base__();

    let rFiles = [];
    let gFiles = [];
    let bFiles = [];
    let outputPathList = [];
    let outputDirectory = "";

    let xisfFileFormat = new FileFormat(".xisf", true/*toRead*/, false/*toWrite*/);

    let table = new TreeBox(this);
    table.alternateRowColor = true;
    table.setScaledMinSize(600, 300);
    table.numberOfColumns = 3;
    table.headerVisible = true;
    table.alternateRowColor = true;
    table.setHeaderText(0, "R");
    table.setHeaderText(1, "G");
    table.setHeaderText(2, "B");
    table.setHeaderIcon(0, createColorSquare(0xFFFF0000)); // Red
    table.setHeaderIcon(1, createColorSquare(0xFF00FF00)); // Green
    table.setHeaderIcon(2, createColorSquare(0xFF0000FF)); // Blue
    table.rootDecoration = false;
    table.setColumnWidth(0, 200);
    table.setColumnWidth(1, 200);
    table.setColumnWidth(2, 200);

    this.getFileInfo = (file) => {
        if (xisfFileFormat.isNull)
            throw new Error("No installed file format can read \'" + ext + "\' files."); // shouldn't happen

        var f = new FileFormatInstance(xisfFileFormat);
        if (f.isNull)
            throw new Error("Unable to instantiate file format: " + xisfFileFormat.name);

        var info = f.open(file, "verbosity 0"); // do not fill the console with useless messages
        if (info.length <= 0)
            throw new Error("Unable to open input file: " + file);

        var keywords = [];
        if (xisfFileFormat.canStoreKeywords)
            keywords = f.keywords;

        f.close();
        let acquisitionDate = keywords.filter(kw => kw.name === "DATE-OBS")[0].value;
        if (!acquisitionDate) {
            console.criticalln("Acquisition Date Not Found !!! " + acquisitionDate);
            acquisitionDate = Date.now();
        }
        else{
            let acquisitionDateTrim = acquisitionDate.replace(/['"]/g, '');
            acquisitionDateOk = acquisitionDateTrim + (acquisitionDateTrim[acquisitionDateTrim.length-1] == "Z" ? "" : "Z");
            //console.writeln("Acquisition Date OK: " + acquisitionDateOk);
            acquisitionDate = new Date(acquisitionDateOk);
        }

        let aqFilter = keywords.filter(kw => kw.name === "FILTER")[0].value;
        console.writeln("Acquisition Date: " + acquisitionDate.toISOString() + " Filter: " + aqFilter);
        return {
            path: file,
            date: acquisitionDate,
            filter: aqFilter
        };
    }

    this.reorderFilesList = () => {
        rFiles.sort((a, b) => new Date(a.date) - new Date(b.date));
        gFiles.sort((a, b) => new Date(a.date) - new Date(b.date));
        bFiles.sort((a, b) => new Date(a.date) - new Date(b.date));
    }


    this.checkIfAlreadyPresent = (fileInfo, list) => {
        let present = false;
        for (let i = 0; i < list.length; i++) {
            let element = list[i];
            if (element.path === fileInfo.path){
                console.writeln(File.extractName(fileInfo.path)+ " Already present!!!");
                present = true;
                break;
            }
          }
        return present;
    }


    this.addFilesButton = new PushButton(this);
    this.addFilesButton.text = "Add Files";
    this.addFilesButton.icon = createMixedColorSquare();
    this.addFilesButton.onClick = () => {
        var ofd = new OpenFileDialog();
        ofd.multipleSelections = true;
        ofd.filters = [["XISF Files", ".xisf"]];
        if (ofd.execute()) {
            let files = ofd.fileNames;
            if (files.length > 0) {
                files.forEach(file => {
                    let fileInfo = this.getFileInfo(file);
                    if (fileInfo.filter.indexOf("R") > -1) {
                        if (this.checkIfAlreadyPresent(fileInfo, rFiles) == false){
                            rFiles.push(fileInfo);
                            console.writeln(File.extractName(file) + " added to R list");
                        }
                        else{
                            console.writeln(File.extractName(file) + " already present in R list. Skipping.");
                        }
                    }
                    else if (fileInfo.filter.indexOf("G") > -1) {
                        if (this.checkIfAlreadyPresent(fileInfo, gFiles) == false){
                            gFiles.push(fileInfo);
                            console.writeln(File.extractName(file) + " added to G list");
                        }
                        else{
                            console.writeln(File.extractName(file) + " already present in G list. Skipping.");
                        }
                    }
                    else if (fileInfo.filter.indexOf("B") > -1) {
                        if (this.checkIfAlreadyPresent(fileInfo, bFiles) == false){
                            bFiles.push(fileInfo);
                            console.writeln(File.extractName(file) + " added to B list");
                        }
                        else{
                            console.writeln(File.extractName(file) + " already present in B list. Skipping.");
                        }
                    }
                });
            }
        }       
        this.updateTable();
    };



    this.addRFilesButton = new PushButton(this);
    this.addRFilesButton.text = "Add R Filter Files";
    this.addRFilesButton.icon = createColorSquare(0xFFFF0000);
    this.addRFilesButton.onClick = () => {
        var ofd = new OpenFileDialog();
        ofd.multipleSelections = true;
        ofd.filters = [["XISF Files", ".xisf"]];
        if (ofd.execute()) {
            let files = ofd.fileNames;
            if (files.length > 0) {
                files.forEach(file => {
                    let fileInfo = this.getFileInfo(file);
                    fileInfo.filter = "R";
                    if (this.checkIfAlreadyPresent(fileInfo, rFiles) == false){
                        rFiles.push(fileInfo);
                        console.writeln(File.extractName(file) + " added to R list Length:" + rFiles.length);
                    }
                    else{
                        console.writeln(File.extractName(file) + " already present in R list. Skipping.");
                    }
                });
            }
        }
        this.updateTable();
    };

    this.addGFilesButton = new PushButton(this);
    this.addGFilesButton.text = "Add G Filter Files";
    this.addGFilesButton.icon = createColorSquare(0xFF00FF00);
    this.addGFilesButton.onClick = () => {
        var ofd = new OpenFileDialog();
        ofd.multipleSelections = true;
        ofd.filters = [["XISF Files", ".xisf"]];
        if (ofd.execute()) {
            let files = ofd.fileNames;
            if (files.length > 0) {
                files.forEach(file => {
                    let fileInfo = this.getFileInfo(file);
                    fileInfo.filter = "G";
                    if (this.checkIfAlreadyPresent(fileInfo, gFiles) == false){
                        gFiles.push(fileInfo);
                        console.writeln(File.extractName(file) + " added to G list. Length:" + gFiles.length);
                    }
                    else{
                        console.writeln(File.extractName(file) + " already present in G list. Skipping.");
                    }
                });
            }
        }
        this.updateTable();
    };

    this.addBFilesButton = new PushButton(this);
    this.addBFilesButton.text = "Add B Filter Files";
    this.addBFilesButton.icon = createColorSquare(0xFF0000FF);
    this.addBFilesButton.onClick = () => {
        var ofd = new OpenFileDialog();
        ofd.multipleSelections = true;
        ofd.filters = [["XISF Files", ".xisf"]];
        if (ofd.execute()) {
            let files = ofd.fileNames;
            if (files.length > 0) {
                files.forEach(file => {
                    let fileInfo = this.getFileInfo(file);
                    fileInfo.filter = "B";
                    if (this.checkIfAlreadyPresent(fileInfo, bFiles) == false){
                        bFiles.push(fileInfo);
                        console.writeln(File.extractName(file) + " added to B list. Length:" + bFiles.length);
                    }
                    else{
                        console.writeln(File.extractName(file) + " already present in B list. Skipping.");
                    }
                });
            }
        }
        this.updateTable();
    };

    let outputDirectoryEdit = new Edit(this);
    outputDirectoryEdit.readOnly = true;
    outputDirectoryEdit.text = outputDirectory;

    this.selectOutputDirectoryButton = new PushButton(this);
    this.selectOutputDirectoryButton.text = "Select Output Directory";
    this.selectOutputDirectoryButton.onClick = () => {
        let gdd = new GetDirectoryDialog;
        gdd.caption = "Select Output Directory";

        if (gdd.execute()) {
            outputDirectory = gdd.directory;
            outputDirectoryEdit.text = outputDirectory;
        }
        this.validateProcessButton();
    };



    this.processButton = new PushButton(this);
    this.processButton.text = "Start Processing";
    this.processButton.onClick = () => {
        let maxLength = Math.max(rFiles.length, gFiles.length, bFiles.length);
        if (maxLength === 0 || !outputDirectory) {
            console.criticalln("No files to process or invalid output directory.");
            return;
        }
        this.addFilesButton.enabled = false;
        this.addRFilesButton.enabled = false;
        this.addGFilesButton.enabled = false;
        this.addBFilesButton.enabled = false;
        this.selectOutputDirectoryButton.enabled = false;
        this.resetFilesButton.enabled = false;
        this.reorderFilesList();

        const sixteenHours = 16 * 60 * 60 * 1000;

        function createSublist(files) {
            let listId=0;
            let sublist = [];
            let currentList = [files[0]];

            for (let i = 1; i < files.length; i++) {
                let currentDate = new Date(files[i].date);
                let previousDate = new Date(currentList[currentList.length - 1].date);

                //console.writeln("Current Date:" + currentDate.toISOString() + " Previous Date:" + previousDate.toISOString());

                if (currentDate - previousDate <= sixteenHours) {
                    currentList.push(files[i]);
                } else {
                    sublist.push(currentList);
                    console.writeln("\tList:" + listId);
                    let ii=1;  
                    currentList.forEach(element => {                                          
                        console.writeln("\t\tElement ("+ ii + "): " + File.extractName(element.path) + " Date: " + element.date.toISOString());
                        ii++;
                    });
                    listId++;
                    currentList = [files[i]];
                }
            }

            if (currentList.length > 0) {
                sublist.push(currentList);
                console.writeln("\tList:" + listId);
                let ii=1;  
                currentList.forEach(element => {                                    
                    console.writeln("\t\tElement ("+ ii + "): " + File.extractName(element.path) + " Date: " + element.date.toISOString());
                    ii++;
                });
                listId++;
            }

            return sublist;
        }

        console.writeln("R SUBLISTS:");
        let rSublist = createSublist(rFiles);
        console.writeln("G SUBLISTS:");
        let gSublist = createSublist(gFiles);
        console.writeln("B SUBLISTS:");
        let bSublist = createSublist(bFiles);
        let imageCount = 0;
        let maxLengthSublists = Math.max(rSublist.length, gSublist.length, bSublist.length)

        let totalImages = 0;
        for (let subI = 0; subI < maxLengthSublists; subI++) {
            let rSub = rSublist[subI];
            let gSub = gSublist[subI];
            let bSub = bSublist[subI];
            maxLength = Math.max(rSub.length, gSub.length, bSub.length);
            totalImages += maxLength;
        }
        outputPathList = [];
        console.writeln("Total number of images to be generated: " + totalImages);

        for (let subI = 0; subI < maxLengthSublists; subI++) {
            let rSub = rSublist[subI];
            let gSub = gSublist[subI];
            let bSub = bSublist[subI];
            maxLength = Math.max(rSub.length, gSub.length, bSub.length);
            for (let i = 0; i < maxLength; i++) {
                imageCount++;
                console.writeln("Generating synthetic Luminance " + (imageCount) +" of " + maxLength + " of total " + totalImages);
                let rIndex = i < rSub.length ? i : rSub.length - 1;
                let gIndex = i < gSub.length ? i : gSub.length - 1;
                let bIndex = i < bSub.length ? i : bSub.length - 1;
                this.generateSyntheticLuminance(rSub[rIndex], gSub[gIndex], bSub[bIndex]);
            }
        }
        this.dialog.ok();
    };

    this.calculateOutpuFilePath = (NewImageId) => {
        let outputFileName = outputDirectory + "/" + NewImageId + ".xisf";
        let counter = 1;
        while (outputPathList.indexOf(outputFileName) != -1) {
            outputFileName = outputDirectory + "/" + NewImageId + "_" + counter + ".xisf" ;
            counter++;
        }
        outputPathList.push(outputFileName);
        return outputFileName;
    };

    this.generateSyntheticLuminance = (rFile, gFile, bFile) => {
        let rWindow = ImageWindow.open(rFile.path)[0];
        let gWindow = ImageWindow.open(gFile.path)[0];
        let bWindow = ImageWindow.open(bFile.path)[0];
        let newImageIdSL = rWindow.mainView.id + "_syntheticL";
        console.writeln("New Image Id: " + newImageIdSL);
        let pixelMath = new PixelMath;
        with (pixelMath) {
            pixelMath.expression = "(" + rWindow.mainView.id + "/3) + (" + gWindow.mainView.id + "/3) + (" + bWindow.mainView.id + "/3)";
            pixelMath.expression1 = pixelMath.expression;
            pixelMath.useSingleExpression = true;
            pixelMath.createNewImage = true;
            pixelMath.newImageId = newImageIdSL;
            pixelMath.newImageColorSpace = PixelMath.prototype.Gray;
            pixelMath.newImageSampleFormat = PixelMath.prototype.f32;
            pixelMath.executeOn(rWindow.mainView);
        }
        let outputWindow= ImageWindow.windowById(newImageIdSL);

        let newKeywords = [];
        let today = new Date();
        let year = today.getFullYear();
        let month = this.pad(today.getMonth() + 1, 2);
        let day = this.pad(today.getDate(), 2);
        let formattedDate = year + "-" + month + "-" + day;
        for ( let i = 0; i < rWindow.keywords.length; ++i )
        {
            let keyword = rWindow.keywords[i];
            if (keyword.name === "COMMENT" || keyword.name === "HISTORY"){
                continue;
            }
            if ( keyword.name.startsWith("PS") || keyword.name.startsWith("ALIGN") || keyword.name.startsWith("NOISE") ){
                continue;
            }
            if ( keyword.name === "FILTER" || keyword.name === "DATE"){
                continue;
            }
            newKeywords.push( keyword );
        }
        newKeywords.push( new FITSKeyword( "DATE", formattedDate, "File creation date" ) );
        newKeywords.push( new FITSKeyword( "FILTER", "L", "Synthetic L from RGB frames" ) );
        outputWindow.keywords = newKeywords;
    
        console.writeln("Saving " + newImageIdSL);
        let outputFilePath = this.calculateOutpuFilePath(newImageIdSL);
        outputWindow.saveAs(outputFilePath, false, false, false, false);
        outputWindow.close();

        rWindow.close();
        gWindow.close();
        bWindow.close();
    };


    this.pad = ( n, c ) =>
    {
       n = String( n );
       while ( n.length < c )
          n = '0' + n;
       return n;
    };
 

    this.cancelButton = new PushButton(this);
    this.cancelButton.text = "Cancel";
    this.cancelButton.onClick = () => {
        if (this.processButton.enabled === false) {
            console.warningln("Processing is being canceled...");
            this.processButton.enabled = true;
            this.addFilesButton.enabled = true;
            this.addRFilesButton.enabled = true;
            this.addGFilesButton.enabled = true;
            this.addBFilesButton.enabled = true;
            this.selectOutputDirectoryButton.enabled = true;
            this.resetFilesButton.enabled = true;
        }
        this.dialog.cancel();
    };

    this.updateTable = () => {
        this.reorderFilesList();
        table.clear();
        let maxLength = Math.max(rFiles.length, gFiles.length, bFiles.length);
        for (let i = 0; i < maxLength; i++) {
            let node = new TreeBoxNode(table);
            if (i < rFiles.length){
                node.setText(0,File.extractName(rFiles[i].path));
            }
            if (i < gFiles.length){
                node.setText(1,File.extractName(gFiles[i].path));
            }
            if (i < bFiles.length){
                node.setText(2,File.extractName(bFiles[i].path));
            }                
        }
        table.adjustColumnWidthToContents( 0 );
        table.adjustColumnWidthToContents( 1 );
        table.adjustColumnWidthToContents( 2 );
        this.validateProcessButton();
    };


    this.validateProcessButton = () => {
        let validPath = outputDirectory != '' && File.directoryExists(outputDirectory) == true;
        let hasFiles = rFiles.length > 0 && gFiles.length > 0 && bFiles.length > 0;
        this.processButton.enabled = validPath && hasFiles;
    };

    this.resetFilesButton = new PushButton(this);
    this.resetFilesButton.text = "Reset Files";
    this.resetFilesButton.icon = this.scaledResource( ":/images/icons/reset.png" );
    this.resetFilesButton.onClick = () => {
        rFiles = [];
        gFiles = [];
        bFiles = [];
        console.writeln("All files have been reset.");
        this.updateTable();
    };

    let outputDirSizer = new HorizontalSizer;
    outputDirSizer.spacing = 6;
    outputDirSizer.add(this.selectOutputDirectoryButton);
    outputDirSizer.add(outputDirectoryEdit, 100);

    let scriptName= "RGB to Synthetic Luminance Generator";
    let version = "1.0.1";

    let headerLabel = new Label(this);
    headerLabel.frameStyle = FrameStyle_Box;
    headerLabel.margin = this.logicalPixelsToPhysical( 4 );
    headerLabel.wordWrapping = true;
    headerLabel.useRichText = true;

    headerLabel.text = "<p><b>" + scriptName + " v" + version + "</b> </p>\n" +
                       "<p>This script combines RGB images to create a synthetic luminance image.\n" +
                       "The files are automatically separated based on the FILTER keyword and they are grouped into sessions considering a maximum session length of 16 consecutive hours.\n" +
                       "You can also add files manually to the R, G, and B lists using the respective buttons.</p>"+
                       "<p>Copyright &copy; 2024 Conci Andrea - Cionki</p>";;
    headerLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.sizer = new VerticalSizer;
    this.sizer.margin = 8;
    this.sizer.spacing = 6;
    this.sizer.add(headerLabel);
    this.sizer.addSpacing(8);
    this.sizer.add(table, 100);
    this.sizer.add(outputDirSizer);
    let addFilesSizer = new HorizontalSizer;
    addFilesSizer.spacing = 6;
    addFilesSizer.add(this.addFilesButton);
    addFilesSizer.add(this.addRFilesButton);
    addFilesSizer.add(this.addGFilesButton);
    addFilesSizer.add(this.addBFilesButton);
    addFilesSizer.addStretch();
    addFilesSizer.add(this.resetFilesButton);

    let actionButtonsSizer = new HorizontalSizer;
    actionButtonsSizer.spacing = 6;
    actionButtonsSizer.addStretch();
    actionButtonsSizer.add(this.cancelButton);
    actionButtonsSizer.add(this.processButton);

    this.sizer.add(addFilesSizer);
    this.sizer.add(actionButtonsSizer);
    this.windowTitle = "RGB to Synthetic Luminance Generator - Conci Andrea - Cionki";
    this.validateProcessButton();
}

RGBCombinerDialog.prototype = new Dialog;

function main() {
    let dialog = new RGBCombinerDialog();
    dialog.execute();
}

main();
